# BodyBlueprint · HealthHub - System Design

## Design principles

- **Local first:** keep profile and daily logs in the user's browser without accounts, remote APIs, or analytics.
- **Explainable:** show the inputs and weights behind the daily score.
- **User controlled:** the person chooses the water goal, can skip the optional BMR coefficient, opts into reminders, and can clear local data.
- **Non-diagnostic:** distinguish estimates and screening metrics from clinical assessment.
- **Small and portable:** use static browser technologies and a standard-library local server for the demonstration.

## Architecture

```mermaid
flowchart LR
    User[User] --> UI[Responsive dashboard]
    UI --> Calc[Calculation and reflection layer]
    UI --> Store[Browser localStorage]
    UI --> Chart[Inline SVG trend view]
    UI --> Print[Browser print stylesheet]
    UI --> Notify[Optional Notification API]
    Demo[14-day fictional sample] --> UI
    Calc --> UI
```

The supplied brief proposes React, Express, and SQLite/localStorage. This version uses plain JavaScript and localStorage to lower setup friction and keep personal health data on-device. It remains a small modular client app with separate calculation, rendering, persistence, and presentation responsibilities. No API server receives metrics.

## Data model

```mermaid
erDiagram
    PROFILE {
        number height_cm
        number current_weight_kg
        number age_years
        string equation_coefficient
        string display_units
        number personal_water_goal_ml
        string optional_name
    }
    DAILY_LOG {
        date date PK
        number water_ml
        string bedtime
        string wake_time
        number restfulness_1_to_5
        number weight_kg
    }
    PROFILE ||--o{ DAILY_LOG : owns_local_entries
```

The app stores one versioned object under a single `localStorage` key. Height and weight are canonicalized to centimeters and kilograms before persistence; display-unit conversions happen at the profile boundary. Each daily entry is keyed by date. The sample JSON file is fictional and the demo page includes a local copy so it can open without a network fetch.

## Wellness score flow

```mermaid
flowchart TD
    Inputs[Profile and selected day's logs] --> BMI[BMI indicator: 0-100]
    Inputs --> Water[Water progress to user goal: 0-100]
    Inputs --> Sleep[Sleep duration progress: 0-100]
    BMI --> Sum[0.30 × BMI + 0.35 × water + 0.35 × sleep]
    Water --> Sum
    Sleep --> Sum
    Sum --> Round[Round to whole number]
    Round --> Display[Display with component breakdown and limits]
```

The normalized score is a hackathon demonstration, not a validated health score. BMI component: `max(0, 100 - 7 × abs(BMI - 21.75))`. Water component: `min(100, 100 × logged_ml / personal_goal_ml)`. Sleep component: `min(100, 100 × hours / 8)`. Composite: weighted sum, rounded to an integer. Missing BMI or sleep receives zero until relevant data is present; the UI should be interpreted as a tracking prototype, not a clinical assessment.

## Main interaction: save a sleep log

```mermaid
sequenceDiagram
    actor Person
    participant UI as Dashboard
    participant Calc as Local calculations
    participant DB as localStorage
    Person->>UI: Choose date, bedtime, wake time, restfulness
    UI->>Calc: Validate times and calculate overnight duration
    Calc-->>UI: Duration and score components
    UI->>DB: Save versioned profile and daily log
    UI-->>Person: Refresh dashboard and seven-day trend
```

## Input and storage safeguards

- Height, weight, age, and water goal have explicit numeric bounds.
- Unit conversions normalize to metric before calculations and storage.
- Adult BMI category display is limited to ages 20+; the app does not attempt pediatric BMI percentiles.
- BMR is omitted when no coefficient is selected.
- Sleep duration handles an overnight boundary when wake time is earlier than bedtime.
- Storage errors are caught and shown; a clear-data action removes the app's local storage key.
- Browser notifications are requested only after a user clicks Enable reminders. The timer runs only while the page is open.

## Privacy and threat boundary

The app does not transmit user metrics. Browser `localStorage` is still accessible to scripts running on the same origin and may be removed by clearing browser data; this is not encrypted or backed up. The local HTTP server is for loopback demo use and is not a production deployment. A hosted deployment would require a separate privacy, security, consent, and retention design.

## Extension path

If the project later needs synchronized accounts, move persistence behind an authenticated API, introduce a database and explicit consent/retention controls, and preserve the client-side calculation boundaries. Before adding personalized health advice or using the composite score beyond a classroom demo, have the criteria reviewed and validated by qualified health professionals.

