# Reference sources

- Adult BMI categories and the screening-measure caveat: [CDC - Adult BMI Categories](https://www.cdc.gov/bmi/adult-calculator/bmi-categories.html)
- BMI formula and adult BMI scope: [CDC - Adult BMI Calculator](https://www.cdc.gov/bmi/adult-calculator/index.html)
- Mifflin–St Jeor equation research record: [PubMed - A new predictive equation for resting energy expenditure in healthy individuals](https://pubmed.ncbi.nlm.nih.gov/2305711/)
- Adult sleep guidance: [CDC - About Sleep](https://www.cdc.gov/sleep/about/)

These references support the educational calculation context. The dashboard's composite wellness score, water goal, sample logs, and reflections are demo features, not official clinical guidance.
