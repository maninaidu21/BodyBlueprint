# BodyBlueprint · HealthHub - Project Report

## 1. Problem and objective

People often track body measurements, water, and sleep in separate tools. BodyBlueprint combines these self-entered metrics in one calm personal dashboard so a user can review daily logs and recent patterns together. The project is a wellness-tracking prototype, not a medical device or clinical decision tool.

## 2. Requirements delivered

- Calculate adult BMI from height and weight and display the standard category bands.
- Estimate resting energy using the Mifflin–St Jeor equation when the user chooses one of its coefficients.
- Log water in 250 ml and 500 ml increments toward a user-selected goal.
- Log bedtime, wake time, duration, and a 1–5 restfulness rating.
- Calculate a 0–100 daily composite from BMI indicator (30%), water (35%), and sleep (35%).
- Show context-aware, non-prescriptive reflections based on entered data.
- Visualize water, sleep, and weight over seven days; include a 14-day sample dataset.
- Print a formatted one-page summary through the browser print dialog.
- Offer optional in-page-session hydration reminders after the user enables notifications.
- Store the profile and logs locally in the browser, with a clear-data action.

## 3. Architecture and implementation

The deliverable is a single-page, responsive browser app implemented with HTML, CSS, and JavaScript. It uses browser `localStorage` as a local persistence layer and inline SVG for the trend visualization. The project's small local server can be started with Python's standard library. This keeps the demo dependency-free and avoids sending wellness logs to an external service. `SYSTEM_DESIGN.md` contains architecture and workflow diagrams.

## 4. Calculations

BMI is calculated as weight in kilograms divided by height in meters squared. Adult category bands are underweight below 18.5, healthy range from 18.5 to below 25, overweight from 25 to below 30, and obesity range at 30 or higher. The interface restricts adult BMI categorization to profiles aged 20 and over.

The Mifflin–St Jeor estimate uses metric height and weight internally. The displayed estimate is a formula-based resting energy value, not an individualized calorie prescription. Users may skip the coefficient and still use the rest of the dashboard.

The score normalizes each component to a 0–100 range, caps water and sleep progress at 100, applies the brief's weights, and rounds the result. Its BMI component is an intentionally simple educational score centered around BMI 21.75; the score is not validated, diagnostic, or suitable for setting personal health targets.

## 5. Privacy and safety

The app makes no remote API calls. Profile and log data remain in local browser storage on the current device. The included sample values are fictional. The app labels the score as a habit snapshot, explains BMI's screening role, describes energy as an estimate, and avoids treatment recommendations. Users can clear local data from the profile dialog. If the browser profile or site storage is cleared, locally stored records are also removed.

## 6. Limitations and future work

Local browser storage is single-device and tied to the browser profile; it is not encrypted or backed up by this prototype. The notification timer only runs while the page remains open. The score's weighting and BMI normalization are demo rules, not validated health science. A production multi-user service would need authenticated accounts, encrypted storage, consent controls, retention/deletion policies, clinician review of content, and a validated scoring model. It could adopt React, an Express API, and SQLite or another database after those needs are defined.

## 7. Conclusion

BodyBlueprint demonstrates a unified personal wellness view with an explicit local-first data design. It combines the requested calculations and logging features while keeping the assumptions and limits visible to the user.

