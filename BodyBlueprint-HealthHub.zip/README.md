# BodyBlueprint · HealthHub

A private, local-first wellness dashboard for a hackathon demo. It brings adult BMI and resting-energy estimates, water check-ins, sleep logs, a seven-day trend, an explainable wellness score, and a printable summary into one responsive page.

## Start the app

1. Install Python 3.10+ if you do not already have it.
2. Open a terminal in this folder.
3. Run `python -m http.server 8000`.
4. Open `http://localhost:8000` in a browser.

The server serves only these project files. Profile details and daily logs are saved in that browser's `localStorage`; no account or external API is used. The 14-day sample is fictional and is loaded locally by the demo page. Use **Profile & goals → Clear my data** to remove saved profile and log data from this browser and restore the demo.

## Demo steps

1. View BMI, the Mifflin–St Jeor resting-energy estimate, and the daily score.
2. Change the date at the top to inspect the sample 14-day history.
3. Log water with the 250 ml and 500 ml quick-add buttons; undo a recent tap if needed.
4. Enter bedtime and wake time, then save a restfulness rating.
5. Review the 7-day water, sleep, and weight trend and the explanation for each score component.
6. Edit height, weight, age, display units, and your own water goal in Profile & goals.
7. Choose **Print summary** and use the browser's print dialog to save a one-page PDF.
8. Enable optional reminders only if desired. Notifications are requested after the button is clicked and repeat only while the page remains open.

## Score model

The daily demo score is a transparent weighted summary, not a validated health measure:

- BMI indicator: 30%. A simple 0–100 closeness score centered within the adult reference range.
- Water: 35%. Progress toward the personal goal chosen in the app, capped at 100.
- Sleep: 35%. Progress toward an 8-hour display target, capped at 100.

The weights reflect the supplied project brief. This score is for demonstrating data normalization and aggregation; it should not guide clinical decisions. BMI is a screening measure for adults, and the resting energy equation is an estimate.

## Project files

- `index.html` - complete responsive app, styles, calculations, chart, local persistence, and print layout
- `data/sample_14_days.json` - fictional 14-day demo dataset
- `PROJECT_REPORT.md` - requirements, features, and demonstration summary
- `SYSTEM_DESIGN.md` - architecture, data model, workflows, privacy, and design decisions
- `SOURCES.md` - reference links for the formulas and adult sleep context

## Technical choice

The brief suggests React, Node/Express, and SQLite or local storage. This deliverable uses a single static page and browser storage so it can run without package installation, a database service, or sending personal wellness records over a network. The design document describes how the app can move to a React/Express/SQLite architecture if multi-user sync or authenticated storage becomes a real requirement.

